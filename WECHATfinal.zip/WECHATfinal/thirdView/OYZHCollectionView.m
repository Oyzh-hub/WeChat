//
//  OYZHCollectionView.m
//  WECHAT
//
//  Created by apple on 2021/5/6.
//
#import "OYZHTableVView.h"
#import "OYZHCollectionView.h"
#import "Masonry.h"
#import "OYZHTableVView.h"
@interface OYZHCollectionView ()

@end

@implementation OYZHCollectionView

-(instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        _img = [[UIImageView alloc]init];
        [self.contentView addSubview:_img];
        _img.contentMode=UIViewContentModeScaleAspectFill;//如果子视图超过了父视图，那么超出的部分会被剪掉，感觉很牛逼
        _img.clipsToBounds=YES;
        _img.layer.cornerRadius = 5.0;//不是必须设置圆角的话 就别设置 可能会造成性能消耗？影响UI流畅？
    }
    return self;
}

- (void)layoutSubviews {
    [super layoutSubviews];
    _img.frame = self.contentView.frame;
}
@end
