//
//  OYZHTableVView.h
//  WECHAT
//
//  Created by apple on 2021/5/6.
//

#import <UIKit/UIKit.h>
//#import "UILabel+MCLabel.h"
#import "OYZHCustomModel.h"

NS_ASSUME_NONNULL_BEGIN
@class OYZHTableVView;

@protocol OYZhTableViewDelegate <NSObject>
/**
 *  折叠按钮点击代理
 *
 *  @param cell 按钮所属cell
 */
- (void)clickFoldLabel:(OYZHTableVView *)cell;

@end

@interface OYZHTableVView : UITableViewCell

//@property (nonatomic,sOYZHTableViewnary *dataModel;
//朋友圈的属性
@property(nonatomic, strong)UIImageView *iconImg;
@property(nonatomic, strong)UILabel *nameL;
@property(nonatomic, strong)UILabel *textContentL;
@property(nonatomic, strong)UILabel *timeL;
@property(nonatomic, strong)UILabel *personalLibL;
@property (nonatomic,strong)UICollectionView *collectView;
@property (nonatomic,strong)UIView *line;
@property(nonatomic, strong)UIButton *moreBtn;
@property(nonatomic, strong)UIView *toolbar;
@property (nonatomic, strong) NSArray *imgArray;
@property (nonatomic, weak) id<OYZhTableViewDelegate> cellDelegate;

//底部工具栏
@property(nonatomic, strong)OYZHCustomModel*model;

//是否需要收起、全文
@property(nonatomic, assign)BOOL isShowFoldBtn;
@end

NS_ASSUME_NONNULL_END
