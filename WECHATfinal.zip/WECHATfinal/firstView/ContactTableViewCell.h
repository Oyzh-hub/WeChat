//
//  ContactTableViewCell.h
//  WECHAT
//
//  Created by apple on 2021/5/6.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ContactTableViewCell : UITableViewCell

//在这里创建四个控件
@property(nonatomic, strong) UIImageView *iconimage;

@property (nonatomic, strong) UILabel *name;

@property (nonatomic, strong) UILabel *detail;

@property (nonatomic, strong) UILabel *time;

@end

NS_ASSUME_NONNULL_END
