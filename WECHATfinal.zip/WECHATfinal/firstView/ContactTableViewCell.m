//
//  ContactTableViewCell.m
//  WECHAT
//
//  Created by apple on 2021/5/6.
//

#import "ContactTableViewCell.h"
#import "Masonry.h"


@implementation ContactTableViewCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style
                reuseIdentifier:reuseIdentifier];
    if (self) {
        
        _iconimage = [[UIImageView alloc] init];
        _time = [[UILabel alloc] init];
        _detail = [[UILabel alloc] init];
        _name = [[UILabel alloc] init];
        
        [self.contentView addSubview:_iconimage];
        [self.contentView addSubview:_name];
        [self.contentView addSubview:_detail];
        [self.contentView addSubview:_time];
        
        [self.iconimage mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.contentView.mas_left).mas_offset(19);
            make.top.mas_equalTo(self.contentView.mas_top).mas_offset(10);
            make.height.mas_equalTo(@50);
            make.width.mas_equalTo(@40);
        }];
        
        [self.detail mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.contentView.mas_left).mas_offset(70);
            make.top.mas_equalTo(self.contentView.mas_top).mas_offset(45);
            make.height.mas_equalTo(@15);
            make.width.mas_equalTo(@200);
        }];
        
        [self.name mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.contentView.mas_left).mas_offset(70);
            make.top.mas_equalTo(self.contentView.mas_top).mas_offset(1);
            make.height.mas_equalTo(@50);
            make.width.mas_equalTo(@70);
        }];
        
        [self.time mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(self.contentView.mas_right).mas_offset(-20);
            make.top.mas_equalTo(self.contentView.mas_top).mas_offset(15);
            make.height.mas_equalTo(@40);
            make.width.mas_equalTo(@40);
        }];
        
    }
    return self;
}

- (void)awakeFromNib {
    [super awakeFromNib];//确保圆角Ui的正常显示
}

@end
