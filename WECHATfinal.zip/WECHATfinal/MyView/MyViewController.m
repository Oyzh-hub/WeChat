//
//  MyViewController.m
//  WECHAT
//
//  Created by apple on 2021/7/10.
//

#import "MyViewController.h"

@interface MyViewController ()<UIImagePickerControllerDelegate,UINavigationControllerDelegate>
{
    UIImageView * _headerImageView;
}
@end

@implementation MyViewController

- (void)viewDidLoad {

    [super viewDidLoad];
    [self createUI];
}

-(void)createUI{

    _headerImageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 110, 110, 110)];
    _headerImageView.layer.cornerRadius = 50;
    _headerImageView.layer.masksToBounds = YES;
    //设置边框
    _headerImageView.layer.borderColor = [UIColor blackColor].CGColor;
    _headerImageView.layer.borderWidth = 1;
    _headerImageView.backgroundColor =[UIColor grayColor];
    _headerImageView.userInteractionEnabled = YES;
    [self.view addSubview:_headerImageView];
    //点击手势
    UITapGestureRecognizer * tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(changeImage:)];
    [_headerImageView addGestureRecognizer:tap];
}
#pragma mark - 点击手势
-(void)changeImage:(UITapGestureRecognizer *)tap{

    UIAlertController * alert = [UIAlertController alertControllerWithTitle:@"选择照片" message:nil preferredStyle:UIAlertControllerStyleActionSheet];

    //添加相册选项
    [alert addAction:[UIAlertAction actionWithTitle:@"相册" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        //访问相册
        [self loadImageWithType:UIImagePickerControllerSourceTypePhotoLibrary];
    }]];
    //取消按钮
    [alert addAction:[UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil]];
    [self presentViewController:alert animated:YES completion:nil];
}

-(void)loadImageWithType:(UIImagePickerControllerSourceType)type{
    //实例化
    UIImagePickerController * picker= [[UIImagePickerController alloc] init];
    //设置图片来源，相机或者相册
    picker.sourceType = type;
    picker.delegate = self;
    //设置后续是否可编辑
    picker.allowsEditing = YES;
    [self presentViewController:picker animated:YES completion:nil];
}

#pragma mark - 代理方法
//完成选择图片之后的回调 也就是点击系统自带的choose按钮之后调用的方法
-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    NSLog(@"选择照片");
    //多选？？？
    _headerImageView.image  = info[UIImagePickerControllerEditedImage];
    [self dismissViewControllerAnimated:YES completion:nil];//是否动态移除屏幕,默认是向屏幕下方移除屏幕外.
}
//取消选择
-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker{
    [self dismissViewControllerAnimated:YES completion:nil];
}

@end

