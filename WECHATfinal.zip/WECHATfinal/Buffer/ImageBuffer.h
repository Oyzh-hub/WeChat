//
//  ImageBuffer.h
//  WECHAT
//
//  Created by apple on 2021/7/10.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface ImageBuffer : NSObject
//1.存储图片
- (void)storeImage:(NSData *)imageData withImageName:(NSString *)ImageName;
// 2.获取图片
- (NSData *)getImageWithImageName:(NSString *)ImageName;
//3.删除图片
- (void)deleteImageWithImageName:(NSString *)ImageName;

@end

NS_ASSUME_NONNULL_END
