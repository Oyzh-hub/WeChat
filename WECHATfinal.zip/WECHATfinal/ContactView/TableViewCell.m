//
//  TableViewCell.m
//  WECHAT
//
//  Created by apple on 2021/5/7.
//

#import "TableViewCell.h"
#import "Masonry.h"

@implementation TableViewCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier{
    self = [super initWithStyle:style
                reuseIdentifier:reuseIdentifier];
    if (self) {
        
        _relationship = [[UILabel alloc] init];
        _iconimage2 = [[UIImageView alloc] init];
        
        [self.contentView addSubview:_relationship];
        [self.contentView addSubview:_iconimage2];
        
        //Masonry布局
        [self.iconimage2 mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.contentView.mas_left).mas_offset(17);
            make.top.mas_equalTo(self.contentView.mas_top).mas_offset(15);
            make.height.mas_equalTo(@40);
            make.width.mas_equalTo(@40);
        }];
        
        [self.relationship mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.contentView.mas_left).mas_offset(70);
            make.top.mas_equalTo(self.contentView.mas_top).mas_offset(30);
            make.height.mas_equalTo(@15);
            make.width.mas_equalTo(@100);
        }];
    }
    return self;
}

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
