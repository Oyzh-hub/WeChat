//
//  TableViewController.m
//  WECHAT
//
//  Created by apple on 2021/5/7.
//
//联系人界面的搭建
#import "TableViewController.h"
#import "TableViewCell.h"

@interface TableViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic, strong)NSMutableArray *dataArray;
@end

@implementation TableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    UITableView * tableview = [[UITableView alloc] initWithFrame:self.view.frame style:UITableViewStylePlain];
    tableview.delegate = self;
    tableview.dataSource = self;
    [self.view addSubview:tableview];
    //装plist的 数组
   NSArray *array = [NSArray arrayWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"address" ofType:@"plist"]];
    _dataArray = [NSMutableArray arrayWithArray:array];
    NSLog(@"%lu",(unsigned long)[_dataArray count]);
}


//三个代理
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return _dataArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 70;
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString *CellIdentifier = @"Cell";
    
    TableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil) {
            cell = [[TableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        }

    cell.relationship.text = _dataArray[indexPath.row][@"relationship"];
    [cell.iconimage2 setImage:[UIImage imageNamed:@"456"]];
    cell.selectionStyle = NO;
    
    return cell;
    
}


@end
