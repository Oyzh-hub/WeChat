//
//  TableView.m
//  WECHAT
//
//  Created by apple on 2021/5/6.
//

#import "TableView.h"
#import "ContactTableViewCell.h"

@interface TableView ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic, strong)NSMutableArray *dataArray;

@end

@implementation TableView

- (void)viewDidLoad {
    [super viewDidLoad];
    UITableView * tableview = [[UITableView alloc] initWithFrame:self.view.frame style:UITableViewStylePlain];
    tableview.delegate = self;
    tableview.dataSource = self;
    [self.view addSubview:tableview];
   NSArray *array = [NSArray arrayWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"message" ofType:@"plist"]];
    _dataArray = [NSMutableArray arrayWithArray:array];
    NSLog(@"%lu",(unsigned long)[_dataArray count]);
}



-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return _dataArray.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 70;
}


-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString *CellIdentifier = @"Cell";
    
    ContactTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil) {
            cell = [[ContactTableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        }

    cell.detail.text = _dataArray[indexPath.row][@"detail"];
    cell.time.text = _dataArray[indexPath.row][@"time"];
    cell.name.text = _dataArray[indexPath.row][@"name"];
    [cell.iconimage setImage: [UIImage imageNamed:@"123"]];
    //[cell.iconimage setImage: [UIImage imageNamed:@"456"]];
    cell.selectionStyle = NO;
    
    return cell;
    
}


@end
