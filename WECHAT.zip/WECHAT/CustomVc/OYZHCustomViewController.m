//
//  OYZHCustomViewController.m
//  WECHAT
//
//  Created by apple on 2021/5/6.
//

#import "OYZHCustomViewController.h"
#import "Masonry.h"
#import "UIColor+YMHex.h"
#import "OYZHTableVView.h"
@interface OYZHCustomViewController ()<UITableViewDelegate,UITableViewDataSource,OYZhTableViewDelegate>
@property (nonatomic,strong)UITableView *tableView;

@property (nonatomic,strong)NSMutableArray *dataSource;

@end

@implementation OYZHCustomViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.view addSubview:self.tableView];
    
    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
        
        make.edges.equalTo(@0);
        
    }];
    
    [self GetData];
    [self.tableView reloadData];
}
- (void)viewDidAppear:(BOOL)animated {
    NSLog(@"--------000-----%f",self.tableView.frame.size.height);
    
}
- (NSMutableArray *)dataSource {
    
    if (!_dataSource) {
        
        _dataSource = [NSMutableArray array];
        
    }
    return _dataSource;
    
}
- (void)GetData {
    for (int i = 0; i < 10; i ++) {
        OYZHCustomModel *model = [[OYZHCustomModel alloc] init];
        model.idStr = [NSString stringWithFormat:@"%d",i];
        model.iconImg = @"123";
        model.nickname = @"紫";
        model.timeStr = @"2021-05-06";
        model.personal = @"知名博主";
        model.textContent = @"5月6日，外交部发言人汪文斌主持例行记者会。有记者提问，中国国家发展改革委6日发布声明，举行自即日起，无限期暂停国家发展改革委与澳联邦政府相关部门共同牵头的中澳战略经济对话机制下的一切活动。发言人对此有何评论？";
        model.imageArr =  @[@"123",@"123",@"123",@"123",@"123"];
        if ( i == 0) {
            model.textContent = @"你好地球";
        }
        if (i == 1) {
            model.textContent = @"5月6日，外交部发言人汪文斌主持例行记者会。有记者提问，中国国家发展改革委6日发布声明，举行自即日起，无限期暂停国家发展改革委与澳联邦政府相关部门共同牵头的中澳战略经济对话机制下的一切活动。发言人对此有何评论？";
        }
        [self.dataSource addObject:model];
    }
    
}
#pragma mark
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return _dataSource.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString *CellIdentifier = @"Cell";
    
    OYZHTableVView *cell = [tableView cellForRowAtIndexPath:indexPath];
    
    if (!cell) {
        cell = [[OYZHTableVView alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    cell.selectionStyle = NO;
    OYZHCustomModel *model = self.dataSource[indexPath.row];
    cell.cellDelegate = self;
    cell.model = model;
    
    return cell;
    
}

-(UITableView *)tableView{
    if (!_tableView) {
        
        _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStylePlain];
        
        _tableView.delegate = self;
        
        _tableView.dataSource = self;
        _tableView.backgroundColor = [UIColor colorWithHexString:@"#eeeeee"];
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        
        //高度自适应
        _tableView.rowHeight = UITableViewAutomaticDimension;
        
        _tableView.estimatedRowHeight = 50;
        
    }
    
    return _tableView;
    
}
-(void)clickFoldLabel:(OYZHTableVView *)cell{
    
    NSIndexPath * indexPath = [self.tableView indexPathForCell:cell];
    OYZHCustomModel *model = self.dataSource[indexPath.row];
    model.isShowMore = !model.isShowMore;
    [UIView setAnimationsEnabled:NO];
    [self.tableView beginUpdates];
    [self.tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationNone];
    [self.tableView endUpdates];
    [UIView setAnimationsEnabled:YES];

}

@end
