//
//  OYZHCollectionView.h
//  WECHAT
//
//  Created by apple on 2021/5/6.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface OYZHCollectionView : UICollectionViewCell
@property (nonatomic,strong)UIImageView *img;
@end

NS_ASSUME_NONNULL_END
