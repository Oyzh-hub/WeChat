//
//  OYZHCollectionView.m
//  WECHAT
//
//  Created by apple on 2021/5/6.
//
#import "OYZHTableVView.h"
#import "OYZHCollectionView.h"
#import "Masonry.h"
#import "OYZHTableVView.h"
@interface OYZHCollectionView ()

@end

@implementation OYZHCollectionView

-(instancetype)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        
        _img = [[UIImageView alloc]init];
        [self.contentView addSubview:_img];
        _img.contentMode=UIViewContentModeScaleAspectFill;
        _img.clipsToBounds=YES;
        _img.layer.cornerRadius = 5.0;
    }
    return self;
}
- (void)layoutSubviews {
    [super layoutSubviews];
    _img.frame = self.contentView.frame;
}
@end
