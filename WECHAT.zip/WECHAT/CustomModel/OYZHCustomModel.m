//
//  OYZHCustomModel.m
//  WECHAT
//
//  Created by apple on 2021/5/6.
//

#import "OYZHCustomModel.h"

@implementation OYZHCustomModel : NSObject 

@end
