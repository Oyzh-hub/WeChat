//
//  SceneDelegate.h
//  WECHAT
//
//  Created by apple on 2021/5/6.
//

#import <UIKit/UIKit.h>

@interface SceneDelegate : UIResponder <UIWindowSceneDelegate>

@property (strong, nonatomic) UIWindow * window;

@end

