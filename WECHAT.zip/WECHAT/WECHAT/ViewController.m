//
//  ViewController.m
//  WECHAT
//
//  Created by apple on 2021/5/6.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor redColor];
}



@end
