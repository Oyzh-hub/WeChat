//
//  CollectionViewCell.m
//  WECHAT
//
//  Created by apple on 2021/7/10.
//

#import "CollectionViewCell.h"

@implementation CollectionViewCell
-(instancetype)initWithFrame:(CGRect)frame
{
    self=[super initWithFrame:frame];
    if(self)
    {
        self.bgIamge=[[UIImageView alloc]init];
        [self.contentView addSubview:self.bgIamge];
        self.bgIamge.frame=CGRectMake(0,0,98,98);
        self.backgroundColor = [UIColor redColor];
    }
    return self;
}
@end
