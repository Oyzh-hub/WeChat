//
//  ReleaseViewController.h
//  WECHAT
//
//  Created by apple on 2021/7/10.
//

#import <UIKit/UIKit.h>
#import "OYZHCustomModel.h"

NS_ASSUME_NONNULL_BEGIN

@protocol passValue <NSObject>

-(void)passedValue1:(UITextView *)text;
-(void)passedValue2:(NSMutableArray *)ary;

@end
//自定义block类型
typedef void(^passvalueBlock)(NSString *text,NSArray *imgArray);
@interface ReleaseViewController : UIViewController
@property (nonatomic,strong) NSMutableArray *photoAry;

@property (nonatomic, strong) passvalueBlock block;
//passvaule的一个属性
@property(nonatomic, weak) id<passValue> delegate;


@end

NS_ASSUME_NONNULL_END
