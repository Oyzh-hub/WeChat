//
//  ReleaseViewController.m
//  WECHAT
//
//  Created by apple on 2021/7/10.
//

#import "ReleaseViewController.h"
#import "ImageBuffer.h"
#import <PhotosUI/PHPicker.h>
#import "Masonry.h"
#import "OYZHCustomModel.h"
#import "CollectionViewCell.h"

@interface ReleaseViewController ()<UITextViewDelegate,PHPickerViewControllerDelegate,UICollectionViewDelegate,UICollectionViewDataSource,UICollectionViewDelegateFlowLayout>

@property (nonatomic,strong) UIScrollView *scrollView;
@property (nonatomic,strong) UITextView *textView;
@property (nonatomic,strong) UILabel *placeholder;
@property (nonatomic,strong) UIImage *Img;
@property (nonatomic,strong) UICollectionView *cv;
@property (nonatomic,strong) UIButton *ReleaseBtn;
@property (nonatomic,strong) UIButton *CancelBtn;
@end

@implementation ReleaseViewController

- (void)viewWillAppear:(BOOL)animated{
    self.navigationController.navigationBar.hidden = NO;
    self.tabBarController.tabBar.hidden = NO;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor whiteColor];
    self.navigationItem.title = @"第二个界面";
    
    UIButton * ReleaseBtn = [[UIButton alloc] initWithFrame:CGRectMake(300, 100, 60, 30)];
    [ReleaseBtn setTitle:@" 发布" forState: UIControlStateNormal];
    [ReleaseBtn setTitleColor:[UIColor greenColor] forState:(UIControlState)UIControlStateNormal];
    [self.view addSubview:ReleaseBtn];
    [ReleaseBtn addTarget:self action:@selector(Release2) forControlEvents:UIControlEventTouchUpInside];
    
    UIButton * CancelBtn = [[UIButton alloc] initWithFrame:CGRectMake(30, 100, 60, 30)];
    [CancelBtn setTitle:@" 取消" forState: UIControlStateNormal];
    [CancelBtn setTitleColor:[UIColor blackColor] forState:(UIControlState)UIControlStateNormal];
    [self.view addSubview:CancelBtn];
    [CancelBtn addTarget:self action:@selector(pop1) forControlEvents:UIControlEventTouchUpInside];
    
    
    NSUserDefaults *def = [NSUserDefaults standardUserDefaults];
    NSInteger count = [def integerForKey:@"count"];
    ImageBuffer *buffer = [[ImageBuffer alloc]init];
    
    UITextView * textview =[ [UITextView alloc] initWithFrame:CGRectMake(0, 150, 414, 160)];
    textview.backgroundColor = [UIColor whiteColor];
    self.textView = textview;
    self.textView.delegate = self;
    
    [self.view addSubview:textview];
    self.placeholder = [[UILabel alloc]initWithFrame:CGRectMake(20, 0, 200, 30)];
    [self.view addSubview:self.textView];
    self.placeholder.textColor = [UIColor grayColor];
    self.placeholder.text = @"说点儿什么吧..";
    [self.textView addSubview:self.placeholder];
    if (!(self.textView.text.length == 0)) {
        self.placeholder.hidden = YES;
    }
  
    
    self.Img = [UIImage imageNamed:@"Img"];
    self.photoAry = [[NSMutableArray alloc]initWithCapacity:9];
    
    //1创建布局类
    UICollectionViewFlowLayout *layout=[[UICollectionViewFlowLayout alloc]init];
    //设置最行小间距
    layout.minimumLineSpacing = 10;
    //设置最小列间距
    layout.minimumInteritemSpacing = 10;
    //设置上下左右四边距
    layout.sectionInset = UIEdgeInsetsMake(15,15,15,15);
    //设置滚动的方向
    layout.scrollDirection = UICollectionViewScrollDirectionVertical;
    
    //2
    self.cv=[[UICollectionView alloc]initWithFrame:CGRectMake(0, 300, 414, 400) collectionViewLayout:layout];
    self.cv.backgroundColor=[UIColor whiteColor];
    //[self.scrollView addSubview:self.cv];
    self.cv.contentInset=UIEdgeInsetsMake(20, 0, 0, 0);//下移20
    [self.view addSubview:self.cv];
    self.cv.delegate = self;
    self.cv.dataSource = self;
    //注册cell
    [self.cv registerClass:[CollectionViewCell class] forCellWithReuseIdentifier:@"cell"];
    if (self.textView.text.length == 0) {
        self.ReleaseBtn.enabled = NO;
        self.ReleaseBtn.backgroundColor = [UIColor systemGray2Color];
    }
    
   

    //initWithCapacity 确定容量提高性能: 如果预先知道数组中要放x个数据就使用[[NSMutableArray alloc]initWithCapacity:x]他会预先开辟x个容量,这样可以提高性能.
    NSMutableArray * mArray = [[NSMutableArray alloc]initWithCapacity:9];
    for (int i = 0; i < count; i++) {
        NSData * data = [buffer getImageWithImageName:[NSString stringWithFormat:@"buffer%d",i]];
        UIImage *img = [UIImage imageWithData:data];
       
        [mArray addObject:img];
    }
    if (count == 0) {
        [self.photoAry addObject:self.Img];
        [self.cv reloadData];
    }
    else{
        self.photoAry = mArray;
        [self.cv reloadData];
    }
    // bringsubviewtofront 将 b放在a上面 直接调整其层级
    [self.view bringSubviewToFront:self.CancelBtn];
        [self.view bringSubviewToFront:self.ReleaseBtn];
    
    
    //两个按钮的方法
    [self.CancelBtn addTarget:self action:@selector(pop1) forControlEvents:UIControlEventTouchUpInside];
    [self.ReleaseBtn addTarget:self action:@selector(Release2) forControlEvents:UIControlEventTouchUpInside];
}

//文本监听
- (void)textViewDidChange:(UITextView *)textView{
    if (textView.text.length == 0) {
        self.placeholder.frame = CGRectMake(20, 0, 200, 30);
        self.placeholder.hidden = NO;
        self.ReleaseBtn.backgroundColor = [UIColor systemGray2Color];
        self.ReleaseBtn.enabled = NO;
    }
    else{
        self.ReleaseBtn.enabled = YES;
        self.ReleaseBtn.backgroundColor = [UIColor systemGreenColor];
        //CGRectZero是一个高度和宽度为零、位于(0，0)的矩形常量。需要创建边框但还不确定边框大小或位置时，可以使用此常量。此时文本框已经有文字 按理placeholder应当消失
        self.placeholder.frame = CGRectZero;
    }
}


//点击事件
-(void)pop1{
    UIAlertController *alertcon = [UIAlertController alertControllerWithTitle:@"注销" message:@"你确定要取消编辑并退出吗？" preferredStyle:UIAlertControllerStyleActionSheet];

    //如果点击确定 则pop回上一个控制器中
    UIAlertAction *actionsure = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDestructive handler:^(UIAlertAction * _Nonnull action) {
        [self.navigationController popViewControllerAnimated:YES];
    }];
    UIAlertAction *actioncancel = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {

    }];

    //将确认和取消的选项键添加在上面
    [alertcon addAction:actionsure];
    [alertcon addAction:actioncancel];
    [self presentViewController:alertcon animated:YES completion:nil];
}


- (void)Release2{
    NSLog(@"发布");
    NSLog(@"\n\n\n%@",[[self.photoAry firstObject] class]);
    
    if (self.photoAry.count < 1) {
        NSLog(@"啊哈,数据有毛病了");
        return;
    }
    NSMutableArray *imgList = [NSMutableArray arrayWithArray:self.photoAry];//重新创建一个数组，新数组有photoAry中的所有数据
    [imgList removeObjectAtIndex:0];//把第一个元素删除，就是哪个加号图片
    _block(self.textView.text,imgList);//把处理完成之后的数组传回去
    [self.navigationController popViewControllerAnimated:YES];
    self.navigationController.navigationBar.hidden = NO;
    self.tabBarController.tabBar.hidden = NO;
}

//代理方法 仿照第一次上课的课件
#pragma mark- dataSource:
-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    //控制个数
    return self.photoAry.count;
}
-(UICollectionViewCell *)collectionView:(UICollectionView*)collectionView cellForItemAtIndexPath:(nonnull NSIndexPath *)indexPath
{
    CollectionViewCell *cell=[collectionView dequeueReusableCellWithReuseIdentifier:@"cell" forIndexPath:indexPath];
        cell.bgIamge.image = self.photoAry[indexPath.item];

    return cell;
}

#pragma mark- delegate
//控制每个cell的大小
-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake(97, 97);
}
//点击事件
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
    NSLog(@"第%ld个item",indexPath.row);
    if (indexPath.item == 0) {
        PHPickerConfiguration *config = [[PHPickerConfiguration alloc]init];
        config.selectionLimit = 9;
        config.filter = [PHPickerFilter imagesFilter];
        PHPickerViewController *pVC = [[PHPickerViewController alloc]initWithConfiguration:config];
        pVC.delegate = self;
        [self presentViewController:pVC animated:YES completion:nil];
    }
}

#pragma - mark PHPicker Delegate
- (void)picker:(PHPickerViewController *)picker didFinishPicking:(NSArray<PHPickerResult *> *)results{
    //picker消失时的操作
    [picker dismissViewControllerAnimated:YES completion:nil];
    //遍历
    for (PHPickerResult *result in results) {
        //调用 loadObject 方法获取图片
        [result.itemProvider loadObjectOfClass:[UIImage class] completionHandler:^(__kindof id<NSItemProviderReading>  _Nullable object, NSError * _Nullable error) {
            // 回调结果是在异步线程，展示时需要切换到主线程
            if ([object isKindOfClass:[UIImage class]]) {
               //更新作用
                dispatch_async(dispatch_get_main_queue(), ^{
                    if (object) {
                        self.ReleaseBtn.enabled = YES;
                        self.ReleaseBtn.backgroundColor = [UIColor systemGreenColor];
                    }
                    [self.photoAry addObject:object];
                    [self.cv reloadData];
                });
            }
        }];
    }
}

@end
