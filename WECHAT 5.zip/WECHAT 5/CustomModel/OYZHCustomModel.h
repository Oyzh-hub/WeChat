//
//  OYZHCustomModel.h
//  WECHAT
//
//  Created by apple on 2021/5/6.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface OYZHCustomModel : NSObject
//头像
@property(nonatomic, copy)NSString *iconImg;
//昵称
@property(nonatomic, copy)NSString *nickname;
//时间
@property(nonatomic, copy)NSString *timeStr;
//知名博主的小字
@property(nonatomic, copy)NSString *personal;
//n文字内容
@property(nonatomic, copy)NSString *textContent;

//图片
@property(nonatomic, strong)NSArray *imageArr;

//id
@property(nonatomic, copy)NSString *idStr;

@property (nonatomic, assign)BOOL isShowMore;


@end

NS_ASSUME_NONNULL_END
