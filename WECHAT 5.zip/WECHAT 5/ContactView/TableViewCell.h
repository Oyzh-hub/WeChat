//
//  TableViewCell.h
//  WECHAT
//
//  Created by apple on 2021/5/7.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface TableViewCell : UITableViewCell


//联系人界面的两个属性  头像和名称
@property (nonatomic, strong) UIImageView *iconimage2;

@property (nonatomic, strong) UILabel *relationship;
@end

NS_ASSUME_NONNULL_END
