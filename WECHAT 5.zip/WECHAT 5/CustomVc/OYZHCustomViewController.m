//
//  OYZHCustomViewController.m
//  WECHAT
//
//  Created by apple on 2021/5/6.
//

#import "OYZHCustomViewController.h"
#import "Masonry.h"
//#import "UIColor+YMHex.h"
#import "ReleaseViewController.h"
#import "OYZHTableVView.h"
#import "OYZHCustomModel.h"
@interface OYZHCustomViewController ()<UITableViewDelegate,UITableViewDataSource,OYZhTableViewDelegate>
@property (nonatomic,strong)UITableView *tableView;

@property (nonatomic,strong)NSMutableArray *dataSource;
@property (nonatomic,strong) UILabel * textView;
@property(nonatomic, strong)NSString *textContentL;
@property(nonatomic, strong)NSArray *photoAry;
//@property(nonatomic, strong) OYZHCustomModel *model;这个不需要
@end

@implementation OYZHCustomViewController

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    NSLog(@"==========>>>>>>>>>>%lu",(unsigned long)_dataSource.count);
    [self.tableView reloadData];
}
    
- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.view addSubview:self.tableView];
    self.tableView.frame = CGRectMake(0, 88, self.view.frame.size.width, self.view.frame.size.height - 88);
    [[NSUserDefaults standardUserDefaults] setValue:@(NO) forKey:@"_UIConstraintBasedLayoutLogUnsatisfiable"];

//    [self.tableView mas_makeConstraints:^(MASConstraintMaker *make) {
//
//        make.edges.equalTo(@0);
//
//    }];
    UIBarButtonItem * right = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFastForward target:self action:@selector(pushNextController)];
    self.navigationItem.rightBarButtonItem = right;

    
    [self GetData];
    [self.tableView reloadData];
    
    
    
}

-(void)pushNextController{
    __weak OYZHCustomViewController *weakVC = self;//weakf防止循环引用
    ReleaseViewController * rc = [[ReleaseViewController alloc]init];
    rc.block = ^(NSString *text, NSArray *imgArray){
        NSLog(@"\n\n  block");
        NSUInteger count = self->_dataSource.count;
        OYZHCustomModel *model = [[OYZHCustomModel alloc]init];//第一次的经验，结合博客 最好新建一个对象，不要同用一个对象，不然发布第二个的时候会有问题，把第一个的数据给覆盖了
        model.idStr = [NSString stringWithFormat:@"%lu",count];
        model.iconImg = @"456j";
        model.nickname = @"网络高级喷子";
        model.timeStr = @"2021-05-06";
        model.personal = @"键盘侠";
        NSLog(@"\n\n\n\n\n\n\n%@\n\n",text);
        NSLog(@"%@",imgArray);
        model.textContent = text;
        model.imageArr =  imgArray;
        if (weakVC.dataSource.count == 0) {//数据源数据为0时直接添加，大于0时再添加一个
            [weakVC.dataSource addObject:model];
        } else {
            [weakVC.dataSource insertObject:model atIndex:0];
        }
        [weakVC.tableView reloadData];
        
//        self->_model.idStr = [NSString stringWithFormat:@"%lu",count+1];
//        self->_model.iconImg = @"456j";
//        self->_model.nickname = @"SB";
//        self->_model.timeStr = @"2021-05-06";
//        self->_model.personal = @"yy";
//        NSLog(@"\n\n\n\n\n\n\n%@\n\n",text);
//        NSLog(@"%@",imgArray);
//        self->_model.textContent = text;
//        self->_model.imageArr =  imgArray;
//        [self.dataSource addObject:self->_model];
    };
    [self.navigationController pushViewController:rc animated:YES];
}


- (NSMutableArray *)dataSource {
    
    if (!_dataSource) {
        
        _dataSource = [NSMutableArray array];
        
    }
    return _dataSource;
    
}
- (void)GetData {
    
    OYZHCustomModel *model1 = [[OYZHCustomModel alloc] init];
    model1.idStr = [NSString stringWithFormat:@"%d",0];
    model1.iconImg = @"456";
    model1.nickname = @"紫";
    model1.timeStr = @"2021-05-06";
    model1.personal = @"知名博主";
    model1.imageArr =  @[@"123",@"456",@"123",@"456",@"123"];
    model1.textContent = @"hhhh哈哈哈 你好呀";
    [self.dataSource addObject:model1];
    
    OYZHCustomModel *model2 = [[OYZHCustomModel alloc] init];
    model2.idStr = [NSString stringWithFormat:@"%d",1];
    model2.iconImg = @"123";
    model2.nickname = @"sffa";
    model2.timeStr = @"2021-05-06";
    model2.personal = @"sb";
    model2.imageArr =  @[@"123",@"456"];
    model2.textContent = @"哈哈哈哈 太好了吧";
    [self.dataSource addObject:model2];
    
    
    OYZHCustomModel *model3 = [[OYZHCustomModel alloc] init];
    model3.idStr = [NSString stringWithFormat:@"%d",3];
    model3.iconImg = @"123";
    model3.nickname = @"紫色的云";
    model3.timeStr = @"2021-05-06";
    model3.personal = @"副书记";
    model3.imageArr =  @[@"123",@"456",@"123"];
    model3.textContent = @"哈哈哈 这里有三张图";
    [self.dataSource addObject:model3];

    
    
}
#pragma mark
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return _dataSource.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString *CellIdentifier = @"Cell";
    
    OYZHTableVView *cell = [tableView cellForRowAtIndexPath:indexPath];
    
    if (!cell) {
        cell = [[OYZHTableVView alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    cell.selectionStyle = NO;
    OYZHCustomModel *model = self.dataSource[indexPath.row];
    cell.cellDelegate = self;
    cell.model = model;
    
    return cell;
    
}

-(UITableView *)tableView{
    if (!_tableView) {
        
        _tableView = [[UITableView alloc]initWithFrame:CGRectZero style:UITableViewStylePlain];
        
        _tableView.delegate = self;
        
        _tableView.dataSource = self;
        _tableView.backgroundColor = [UIColor grayColor];
        _tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        
        //高度自适应
        _tableView.rowHeight = UITableViewAutomaticDimension;
        
        _tableView.estimatedRowHeight = 50;
        
    }
    
    return _tableView;
    
}
    
-(void)clickFoldLabel:(OYZHTableVView *)cell{
    
    NSIndexPath * indexPath = [self.tableView indexPathForCell:cell];
    OYZHCustomModel *model = self.dataSource[indexPath.row];
    model.isShowMore = !model.isShowMore;
    [UIView setAnimationsEnabled:NO];
    [self.tableView beginUpdates];
    [self.tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationNone];
    [self.tableView endUpdates];
    [UIView setAnimationsEnabled:YES];

}

@end
    
